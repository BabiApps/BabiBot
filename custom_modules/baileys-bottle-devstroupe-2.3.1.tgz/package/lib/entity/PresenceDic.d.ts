import { Auth } from "./Auth.js";
import { Presence } from "./Presence.js";
export declare class PresenceDic {
    DBId: number;
    DBAuth: Auth;
    id: string;
    presences: Presence[];
}
