import { Chat } from "./Chat.js";
import { Contact } from "./Contact.js";
import { GroupMetadata } from "./GroupMetadata.js";
import { MessageDic } from "./MessageDic.js";
import { PresenceDic } from "./PresenceDic.js";
export declare class Auth {
    id: number;
    key: string;
    value: string;
    chats: Chat[];
    contacts: Contact[];
    groups: GroupMetadata[];
    messageDics: MessageDic[];
    presenceDics: PresenceDic[];
}
