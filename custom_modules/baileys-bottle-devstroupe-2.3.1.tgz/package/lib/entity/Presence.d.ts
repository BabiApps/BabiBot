import { WAPresence } from "baileys";
import { PresenceDic } from "./PresenceDic.js";
export declare class Presence {
    DBId: number;
    dictionary: PresenceDic;
    participant: string;
    lastKnownPresence: WAPresence;
    lastSeen?: number;
}
