import { Auth } from "./Auth.js";
export declare class Contact {
    DBId: number;
    DBAuth: Auth;
    authId: number;
    id: string;
    name?: string;
    notify?: string;
    verifiedName?: string;
    imgUrl?: string | "changed";
    status?: string;
}
