import { Auth } from "./Auth.js";
import { Message } from "./Message.js";
export declare class MessageDic {
    id: number;
    DBAuth: Auth;
    jid: string;
    messages: Message[];
}
