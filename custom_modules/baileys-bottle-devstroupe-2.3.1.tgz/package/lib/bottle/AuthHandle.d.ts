import { AuthenticationState } from "baileys";
import { DataSource } from "typeorm";
interface AuthOptions {
    credsFile?: string;
    replace?: boolean;
}
export default class AuthHandle {
    private ds;
    private key;
    constructor(ds: DataSource, key: string);
    private repos;
    useAuthHandle: (options?: AuthOptions) => Promise<{
        state: AuthenticationState;
        saveState: () => Promise<any>;
    }>;
}
export {};
